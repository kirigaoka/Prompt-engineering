# Automotive Copilot Reverse Engineering Template

Instructions:

1. Open source file in src/
2. Run Copilot prompt
3. Copy output to docs/
4. Fill Excel template in templates/

Compliance:

ISO 26262
ASPICE SWE.1 SWE.2 SWE.3
