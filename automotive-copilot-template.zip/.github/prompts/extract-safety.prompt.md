# Extract Safety Requirements

Generate:

SSR-001: The software shall detect faults.
SSR-002: The software shall enter safe state.
