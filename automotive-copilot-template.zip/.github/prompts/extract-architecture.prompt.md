# Extract Architecture

Generate:

- Components
- Interfaces
- Data flow

Include PlantUML diagram.
