# Extract Low-Level Requirements

Generate LLR using format:

LLR-001: The function shall...

Include:
- Input validation
- Control logic
- Outputs
- Error handling
