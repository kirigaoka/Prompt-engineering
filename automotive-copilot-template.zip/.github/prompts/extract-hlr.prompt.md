# Extract High-Level Requirements

Generate HLR using format:

HLR-001: The software shall...

Include:
- Module purpose
- Inputs
- Outputs
- Safety behavior
